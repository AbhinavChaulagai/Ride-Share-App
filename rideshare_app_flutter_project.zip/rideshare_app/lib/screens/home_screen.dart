import 'package:flutter/material.dart';
import 'package:rideshare_app/screens/available_rides_screen.dart'; // Import AvailableRidesScreen
import 'package:rideshare_app/screens/profile_screen.dart'; // Import ProfileScreen
import 'package:rideshare_app/utils/constants.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _fromController = TextEditingController();
  final TextEditingController _toController = TextEditingController();

  @override
  void dispose() {
    _fromController.dispose();
    _toController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('RideShare'),
        automaticallyImplyLeading: false, // Remove back button on home
        actions: [
          IconButton(
            icon: const Icon(Icons.account_circle_outlined),
            tooltip: 'Profile',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const ProfileScreen()),
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Map View Placeholder
            Container(
              height: MediaQuery.of(context).size.height * 0.4, // Adjust height as needed
              color: lightGreyColor, // Placeholder background
              child: const Center(
                child: Text(
                  'Map View Placeholder',
                  style: TextStyle(color: textLightColor),
                ),
              ),
            ),
            // Input and Recent Places Section
            Padding(
              padding: const EdgeInsets.all(defaultPadding),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextField(
                    controller: _fromController,
                    decoration: const InputDecoration(
                      hintText: 'Where are you?',
                      prefixIcon: Icon(Icons.my_location, color: textLightColor),
                    ),
                  ),
                  const SizedBox(height: defaultPadding),
                  TextField(
                    controller: _toController,
                    decoration: const InputDecoration(
                      hintText: 'Where to?',
                      prefixIcon: Icon(Icons.location_on_outlined, color: textLightColor),
                    ),
                  ),
                  const SizedBox(height: defaultPadding * 1.5),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        // Basic validation (can be improved)
                        if (_fromController.text.isNotEmpty && _toController.text.isNotEmpty) {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const AvailableRidesScreen(
                                // Pass actual data if needed, using dummy for now
                                // fromLocation: _fromController.text,
                                // toLocation: _toController.text,
                              ),
                            ),
                          );
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Please enter both pickup and destination locations.')),
                          );
                        }
                      },
                      child: const Text('Find Rides'),
                    ),
                  ),
                  const SizedBox(height: defaultPadding * 2),
                  Text(
                    'Recent Places',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: defaultPadding),
                  _buildRecentPlaceItem(context, Icons.work_outline, 'Office - Sector 62, Noida'),
                  const Divider(color: mediumGreyColor, height: defaultPadding * 1.5),
                  _buildRecentPlaceItem(context, Icons.home_outlined, 'Home - Mayur Vihar Phase 1'),
                  // Add more recent places or make it dynamic later
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRecentPlaceItem(BuildContext context, IconData icon, String place) {
    return InkWell(
      onTap: () {
        // Handle tapping recent place - Fill 'Where to?' field
        _toController.text = place;
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: defaultPadding / 2),
        child: Row(
          children: [
            Icon(icon, color: textLightColor, size: 24),
            const SizedBox(width: defaultPadding),
            Expanded(
              child: Text(
                place,
                style: Theme.of(context).textTheme.bodyLarge,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

