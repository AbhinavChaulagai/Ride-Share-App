import 'dart:async'; // For Timer
import 'package:flutter/material.dart';
import 'package:rideshare_app/screens/ride_details_screen.dart'; // Import RideDetailsScreen
import 'package:rideshare_app/utils/constants.dart';

class FindingCoPassengersScreen extends StatefulWidget {
  // Pass ride details if needed
  final String fromLocation;
  final String toLocation;
  final double distance;
  final String baseFare;
  final String initialSharedFare; // Fare for the selected shared option

  const FindingCoPassengersScreen({
    super.key,
    required this.fromLocation,
    required this.toLocation,
    required this.distance,
    required this.baseFare,
    required this.initialSharedFare,
  });

  @override
  State<FindingCoPassengersScreen> createState() => _FindingCoPassengersScreenState();
}

class _FindingCoPassengersScreenState extends State<FindingCoPassengersScreen> {
  bool _coPassengerFound = false;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    // Simulate finding a co-passenger after a delay
    _timer = Timer(const Duration(seconds: 5), () {
      if (mounted) { // Check if the widget is still in the tree
        setState(() {
          _coPassengerFound = true;
        });
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel(); // Cancel timer if screen is disposed
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Calculate updated fare (assuming 50% split for 1 co-passenger)
    // This logic might need adjustment based on actual sharing rules
    final String updatedFare = _coPassengerFound ? widget.initialSharedFare : '...';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Finding Co-Passengers'),
        automaticallyImplyLeading: false, // Remove back button
      ),
      body: Padding(
        padding: const EdgeInsets.all(defaultPadding * 1.5),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              if (!_coPassengerFound)
                const CircularProgressIndicator(color: primaryColor),
              if (!_coPassengerFound)
                const SizedBox(height: defaultPadding * 2),
              if (!_coPassengerFound)
                Text(
                  'Looking for people traveling the same route...',
                  style: Theme.of(context).textTheme.titleMedium,
                  textAlign: TextAlign.center,
                ),
              if (_coPassengerFound)
                const Icon(Icons.check_circle_outline, color: Colors.green, size: 60),
              if (_coPassengerFound)
                const SizedBox(height: defaultPadding),
              if (_coPassengerFound)
                Text(
                  'Found 1 co-passenger!',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),

              const SizedBox(height: defaultPadding * 3),

              // Ride Details Card
              Card(
                elevation: 2,
                color: lightGreyColor,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(defaultRadius)),
                child: Padding(
                  padding: const EdgeInsets.all(defaultPadding),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Your Ride Details:', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                      const SizedBox(height: defaultPadding),
                      _buildDetailRow('From:', widget.fromLocation),
                      _buildDetailRow('To:', widget.toLocation),
                      _buildDetailRow('Distance:', '${widget.distance} km'),
                      _buildDetailRow('Base Fare:', widget.baseFare),
                      const Divider(height: defaultPadding * 1.5),
                      _buildDetailRow(
                        'Your Fare:',
                        updatedFare,
                        valueStyle: Theme.of(context).textTheme.titleLarge?.copyWith(
                          color: _coPassengerFound ? Colors.green[700] : darkGreyColor,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const Spacer(), // Pushes buttons to the bottom

              // Action Buttons
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _coPassengerFound
                      ? () {
                          // Navigate to Ride Details Screen
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const RideDetailsScreen(
                                // Pass necessary data if needed
                              ),
                            ),
                          );
                        }
                      : null, // Disable button until co-passenger found
                  child: const Text('Continue with Shared Ride'),
                ),
              ),
              const SizedBox(height: defaultPadding),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: () {
                    Navigator.of(context).pop(); // Go back to Available Rides
                  },
                  style: OutlinedButton.styleFrom(
                    foregroundColor: primaryColor,
                    side: const BorderSide(color: primaryColor),
                    padding: const EdgeInsets.symmetric(vertical: defaultPadding * 0.75, horizontal: defaultPadding * 1.5),
                     shape: RoundedRectangleBorder(
                       borderRadius: BorderRadius.circular(defaultRadius),
                     ),
                  ),
                  child: const Text('Cancel'),
                ),
              ),
              const SizedBox(height: defaultPadding), // Bottom padding
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value, {TextStyle? valueStyle}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: defaultPadding / 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: textLightColor)),
          const SizedBox(width: defaultPadding),
          Expanded(
            child: Text(
              value,
              style: valueStyle ?? Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.bold),
              textAlign: TextAlign.right,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}

