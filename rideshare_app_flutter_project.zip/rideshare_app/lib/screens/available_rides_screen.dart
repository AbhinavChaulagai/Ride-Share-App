import 'package:flutter/material.dart';
import 'package:rideshare_app/screens/finding_copassengers_screen.dart'; // Import FindingCoPassengersScreen
import 'package:rideshare_app/utils/constants.dart';

class AvailableRidesScreen extends StatefulWidget {
  // Pass ride details if needed, e.g.:
  // final String fromLocation;
  // final String toLocation;
  // final double distance;

  const AvailableRidesScreen({super.key /*, required this.fromLocation, etc. */});

  @override
  State<AvailableRidesScreen> createState() => _AvailableRidesScreenState();
}

class _AvailableRidesScreenState extends State<AvailableRidesScreen> {
  String? _selectedRideOption; // To track which ride is selected
  String _selectedRidePrice = ''; // To store the price of the selected ride

  @override
  Widget build(BuildContext context) {
    // Dummy data based on mockup - replace with actual data later
    const String fromLocation = 'Connaught Place';
    const String toLocation = 'Gurugram Cyber City';
    const double distance = 28.5;
    const String baseFare = '₹570'; // Base fare for private cab

    return Scaffold(
      appBar: AppBar(
        title: const Text('Available Rides'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(), // Go back
        ),
      ),
      body: Column(
        children: [
          // Ride Details Header
          Padding(
            padding: const EdgeInsets.all(defaultPadding),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('From: $fromLocation', style: Theme.of(context).textTheme.bodyLarge),
                const SizedBox(height: defaultPadding / 2),
                Text('To: $toLocation', style: Theme.of(context).textTheme.bodyLarge),
                const SizedBox(height: defaultPadding / 2),
                Text('Distance: ${distance} km', style: Theme.of(context).textTheme.bodyLarge),
              ],
            ),
          ),
          const Divider(color: mediumGreyColor, height: 1),

          // Ride Options List
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(defaultPadding),
              children: [
                _buildRideOptionCard(
                  context,
                  icon: Icons.directions_car, // Private cab icon
                  title: 'Private Cab',
                  arrivalTime: 'Arrives in 3 mins',
                  price: '₹570',
                  isSelected: _selectedRideOption == 'private',
                  onTap: () => setState(() {
                     _selectedRideOption = 'private';
                     _selectedRidePrice = '₹570';
                  }),
                ),
                const SizedBox(height: defaultPadding),
                _buildRideOptionCard(
                  context,
                  icon: Icons.people_alt_outlined, // Shared ride icon
                  title: 'Shared Ride (2 seats)',
                  arrivalTime: 'Arrives in 5 mins',
                  price: '₹285',
                  savingsInfo: '50% savings with ride sharing!',
                  isSelected: _selectedRideOption == 'shared_2',
                  onTap: () => setState(() {
                     _selectedRideOption = 'shared_2';
                     _selectedRidePrice = '₹285';
                  }),
                ),
                const SizedBox(height: defaultPadding),
                _buildRideOptionCard(
                  context,
                  icon: Icons.people, // Different shared ride icon
                  title: 'Shared Ride (3 seats)',
                  arrivalTime: 'Arrives in 8 mins',
                  price: '₹190',
                  savingsInfo: '66% savings with ride sharing!',
                  isSelected: _selectedRideOption == 'shared_3',
                  onTap: () => setState(() {
                     _selectedRideOption = 'shared_3';
                     _selectedRidePrice = '₹190';
                  }),
                ),
              ],
            ),
          ),

          // Book Button Footer
          Padding(
            padding: const EdgeInsets.all(defaultPadding),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _selectedRideOption == null || _selectedRideOption == 'private'
                    ? null // Disable if no shared ride selected or private selected
                    : () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => FindingCoPassengersScreen(
                              // Pass dummy data based on current screen
                              fromLocation: fromLocation,
                              toLocation: toLocation,
                              distance: distance,
                              baseFare: baseFare, // Pass the original base fare
                              initialSharedFare: _selectedRidePrice, // Pass the selected shared fare
                            ),
                          ),
                        );
                      },
                child: const Text('Book Shared Ride'),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRideOptionCard(
    BuildContext context,
    {
      required IconData icon,
      required String title,
      required String arrivalTime,
      required String price,
      String? savingsInfo,
      required bool isSelected,
      required VoidCallback onTap,
    }
  ) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(defaultPadding),
        decoration: BoxDecoration(
          color: isSelected ? primaryColor.withOpacity(0.1) : lightGreyColor,
          borderRadius: BorderRadius.circular(defaultRadius),
          border: Border.all(
            color: isSelected ? primaryColor : mediumGreyColor,
            width: isSelected ? 1.5 : 1.0,
          ),
        ),
        child: Row(
          children: [
            Icon(icon, color: isSelected ? primaryColor : darkGreyColor, size: 30),
            const SizedBox(width: defaultPadding),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: defaultPadding / 4),
                  Text(arrivalTime, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: textLightColor)),
                  if (savingsInfo != null)
                    Padding(
                      padding: const EdgeInsets.only(top: defaultPadding / 4),
                      child: Text(
                        savingsInfo,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.green[700]),
                      ),
                    ),
                ],
              ),
            ),
            Text(
              price,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    color: isSelected ? primaryColor : darkGreyColor,
                    fontWeight: FontWeight.bold,
                  ),
            ),
          ],
        ),
      ),
    );
  }
}

