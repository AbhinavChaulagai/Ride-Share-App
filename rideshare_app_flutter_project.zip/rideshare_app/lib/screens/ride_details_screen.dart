import 'package:flutter/material.dart';
import 'package:rideshare_app/utils/constants.dart';

class RideDetailsScreen extends StatelessWidget {
  // Pass necessary ride/driver/co-passenger data here
  const RideDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Dummy data based on mockup - replace with actual data later
    const String carModel = 'Maruti Swift - DL 01 AB 1234';
    const String arrivalTime = 'Arriving in 3 minutes';
    const String driverName = 'Rajesh Kumar';
    const double driverRating = 4.2;
    const String coPassengerName = 'Priya S.';
    const String coPassengerPickup = 'Pickup: Connaught Place';
    const String distance = '28.5 km';
    const String baseFare = '₹570';
    const String sharedInfo = 'Shared with: 1 passenger';
    const String yourFare = '₹285';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Ride Details'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
        // Potentially add cancel/help options
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Live Tracking Map Placeholder
            Container(
              height: MediaQuery.of(context).size.height * 0.35,
              color: lightGreyColor,
              child: const Center(
                child: Text(
                  'Live Tracking Map Placeholder',
                  style: TextStyle(color: textLightColor),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(defaultPadding),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Vehicle Details
                  _buildSectionCard(
                    context,
                    child: Row(
                      children: [
                        const Icon(Icons.directions_car, color: primaryColor, size: 40),
                        const SizedBox(width: defaultPadding),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(carModel, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                              const SizedBox(height: defaultPadding / 4),
                              Text(arrivalTime, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: textLightColor)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: defaultPadding),

                  // Driver Details
                  Text('Driver Details', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: defaultPadding / 2),
                  _buildSectionCard(
                    context,
                    child: Row(
                      children: [
                        const CircleAvatar(
                          radius: 25,
                          backgroundColor: mediumGreyColor,
                          child: Icon(Icons.person, color: Colors.white, size: 30), // Placeholder Icon
                        ),
                        const SizedBox(width: defaultPadding),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(driverName, style: Theme.of(context).textTheme.titleMedium),
                              Row(
                                children: [
                                  const Icon(Icons.star, color: Colors.amber, size: 18),
                                  const SizedBox(width: 4),
                                  Text(driverRating.toString(), style: Theme.of(context).textTheme.bodyMedium),
                                ],
                              ),
                            ],
                          ),
                        ),
                        // Add Call/Message Icons if needed
                        IconButton(onPressed: () {}, icon: const Icon(Icons.call_outlined, color: primaryColor)),
                      ],
                    ),
                  ),
                  const SizedBox(height: defaultPadding),

                  // Co-Passengers Details
                  Text('Co-Passengers', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: defaultPadding / 2),
                  _buildSectionCard(
                    context,
                    child: Row(
                      children: [
                        const CircleAvatar(
                          radius: 20,
                          backgroundColor: mediumGreyColor,
                          child: Icon(Icons.person_outline, color: Colors.white, size: 24), // Placeholder Icon
                        ),
                        const SizedBox(width: defaultPadding),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(coPassengerName, style: Theme.of(context).textTheme.bodyLarge),
                              Text(coPassengerPickup, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: textLightColor)),
                            ],
                          ),
                        ),
                         // Add Call/Message Icons if needed
                      ],
                    ),
                  ),
                  const SizedBox(height: defaultPadding),

                  // Fare Details
                  Text('Fare Details', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: defaultPadding / 2),
                  _buildSectionCard(
                    context,
                    child: Column(
                      children: [
                        _buildFareDetailRow(context, 'Distance:', distance),
                        _buildFareDetailRow(context, 'Base Fare (20 Rs/km):', baseFare),
                        _buildFareDetailRow(context, sharedInfo, ''),
                        const Divider(height: defaultPadding),
                        _buildFareDetailRow(context, 'Your Fare:', yourFare, isTotal: true),
                      ],
                    ),
                  ),
                   const SizedBox(height: defaultPadding * 2), // Space at bottom
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionCard(BuildContext context, {required Widget child}) {
    return Card(
      elevation: 1,
      color: lightGreyColor.withOpacity(0.5),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(defaultRadius)),
      child: Padding(
        padding: const EdgeInsets.all(defaultPadding),
        child: child,
      ),
    );
  }

  Widget _buildFareDetailRow(BuildContext context, String label, String value, {bool isTotal = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: defaultPadding / 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(color: isTotal ? darkGreyColor : textLightColor)),
          Text(
            value,
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
                  color: isTotal ? primaryColor : darkGreyColor,
                ),
          ),
        ],
      ),
    );
  }
}

