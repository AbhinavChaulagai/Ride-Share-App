import 'package:flutter/material.dart';

// Define primary and secondary colors based on the mockup
const Color primaryColor = Color(0xFF4A90E2); // Blue color from buttons/header
const Color secondaryColor = Color(0xFF50E3C2); // A teal/green accent (can adjust if needed)
const Color lightGreyColor = Color(0xFFF4F4F4); // Light background grey
const Color mediumGreyColor = Color(0xFFBDBDBD); // Borders, dividers
const Color darkGreyColor = Color(0xFF4A4A4A); // Primary text
const Color textLightColor = Color(0xFF757575); // Secondary text / hints

// Standard padding/margin values
const double defaultPadding = 16.0;
const double defaultMargin = 16.0;
const double defaultRadius = 8.0;

