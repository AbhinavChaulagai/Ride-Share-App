import 'package:flutter/material.dart';
import 'package:rideshare_app/screens/rating_screen.dart'; // Import RatingScreen
import 'package:rideshare_app/utils/constants.dart';

class PaymentScreen extends StatefulWidget {
  // Pass necessary ride/fare data here
  const PaymentScreen({super.key});

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

enum PaymentMethod { card, upi, cash }

class _PaymentScreenState extends State<PaymentScreen> {
  PaymentMethod? _selectedPaymentMethod = PaymentMethod.card; // Default selection

  @override
  Widget build(BuildContext context) {
    // Dummy data based on mockup - replace with actual data later
    const String route = 'Connaught Place to Gurugram Cyber City';
    const String finalFare = '₹285';
    const String distance = '28.5 km';
    const String duration = '45 minutes';
    const String baseFare = '₹570';
    const String sharedInfo = 'Shared with: 1 passenger';
    const String savedAmount = '₹285';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Payment'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(defaultPadding),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(height: defaultPadding),
                  Text(
                    'Ride Completed',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(color: primaryColor),
                  ),
                  const SizedBox(height: defaultPadding / 2),
                  Text(route, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: textLightColor)),
                  const SizedBox(height: defaultPadding * 1.5),
                  Chip(
                    label: Text(finalFare, style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: Colors.white, fontWeight: FontWeight.bold)),
                    backgroundColor: primaryColor,
                    padding: const EdgeInsets.symmetric(horizontal: defaultPadding * 1.5, vertical: defaultPadding / 2),
                  ),
                  const SizedBox(height: defaultPadding * 2),

                  // Ride Summary Card
                  Card(
                    elevation: 1,
                    color: lightGreyColor.withOpacity(0.5),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(defaultRadius)),
                    child: Padding(
                      padding: const EdgeInsets.all(defaultPadding),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Ride Summary:', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                          const SizedBox(height: defaultPadding),
                          _buildSummaryRow(context, 'Distance:', distance),
                          _buildSummaryRow(context, 'Duration:', duration),
                          _buildSummaryRow(context, 'Base Fare (20 Rs/km):', baseFare),
                          _buildSummaryRow(context, sharedInfo, ''),
                          const Divider(height: defaultPadding * 1.5),
                          _buildSummaryRow(context, 'Your Fare:', finalFare, isHighlight: true),
                          _buildSummaryRow(context, 'You saved:', savedAmount, isSavings: true),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: defaultPadding * 2),

                  // Payment Method Section
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text('Payment Method', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                  ),
                  const SizedBox(height: defaultPadding),
                  _buildPaymentMethodOption(
                    context,
                    icon: Icons.credit_card,
                    title: 'Credit/Debit Card',
                    subtitle: '**** **** **** 1234',
                    value: PaymentMethod.card,
                  ),
                  const SizedBox(height: defaultPadding / 2),
                  _buildPaymentMethodOption(
                    context,
                    icon: Icons.smartphone, // Using smartphone for UPI
                    title: 'UPI',
                    subtitle: 'user@upi',
                    value: PaymentMethod.upi,
                  ),
                  const SizedBox(height: defaultPadding / 2),
                  _buildPaymentMethodOption(
                    context,
                    icon: Icons.money,
                    title: 'Cash',
                    subtitle: null,
                    value: PaymentMethod.cash,
                  ),
                ],
              ),
            ),
          ),

          // Pay Now Button Footer
          Padding(
            padding: const EdgeInsets.all(defaultPadding),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _selectedPaymentMethod == null
                    ? null
                    : () {
                        // Simulate successful payment
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (context) => const RatingScreen()),
                        );
                      },
                child: const Text('Pay Now'),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryRow(BuildContext context, String label, String value, {bool isHighlight = false, bool isSavings = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: defaultPadding / 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(color: textLightColor)),
          Text(
            value,
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  fontWeight: isHighlight || isSavings ? FontWeight.bold : FontWeight.normal,
                  color: isSavings ? Colors.green[700] : (isHighlight ? primaryColor : darkGreyColor),
                ),
          ),
        ],
      ),
    );
  }

  Widget _buildPaymentMethodOption(
    BuildContext context,
    {
      required IconData icon,
      required String title,
      required String? subtitle,
      required PaymentMethod value,
    }
  ) {
    bool isSelected = _selectedPaymentMethod == value;
    return Card(
       elevation: 0,
       margin: EdgeInsets.zero, // Remove card margin
       shape: RoundedRectangleBorder(
         borderRadius: BorderRadius.circular(defaultRadius),
         side: BorderSide(color: isSelected ? primaryColor : mediumGreyColor, width: isSelected ? 1.5 : 1.0),
       ),
       color: isSelected ? primaryColor.withOpacity(0.05) : Colors.white,
       child: RadioListTile<PaymentMethod>(
         secondary: CircleAvatar(
           radius: 20,
           backgroundColor: lightGreyColor,
           child: Icon(icon, color: textLightColor, size: 20),
         ),
         title: Text(title, style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.bold)),
         subtitle: subtitle != null ? Text(subtitle, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: textLightColor)) : null,
         value: value,
         groupValue: _selectedPaymentMethod,
         onChanged: (PaymentMethod? newValue) {
           setState(() {
             _selectedPaymentMethod = newValue;
           });
         },
         activeColor: primaryColor,
         contentPadding: const EdgeInsets.symmetric(horizontal: defaultPadding, vertical: defaultPadding / 2),
       ),
    );
  }
}

