import 'package:flutter/material.dart';
import 'package:rideshare_app/screens/home_screen.dart'; // Import HomeScreen
import 'package:rideshare_app/utils/constants.dart';

class RatingScreen extends StatefulWidget {
  // Pass necessary driver/co-passenger data here
  const RatingScreen({super.key});

  @override
  State<RatingScreen> createState() => _RatingScreenState();
}

class _RatingScreenState extends State<RatingScreen> {
  double _driverRating = 4.0; // Initial rating based on mockup
  double _coPassengerRating = 5.0; // Initial rating based on mockup
  final TextEditingController _feedbackController = TextEditingController();

  @override
  void dispose() {
    _feedbackController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Dummy data based on mockup - replace with actual data later
    const String driverName = 'Rajesh Kumar';
    const String coPassengerName = 'Priya S.';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Rate Your Experience'),
        // Hide back button as this is the final step in the flow
        automaticallyImplyLeading: false,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(defaultPadding * 1.5),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: defaultPadding),
            // Driver Rating Section
            const CircleAvatar(
              radius: 40,
              backgroundColor: mediumGreyColor,
              child: Icon(Icons.person, color: Colors.white, size: 50), // Placeholder Icon
            ),
            const SizedBox(height: defaultPadding),
            Text(driverName, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: defaultPadding / 2),
            Text('How was your ride?', style: Theme.of(context).textTheme.titleMedium?.copyWith(color: textLightColor)),
            const SizedBox(height: defaultPadding / 2),
            _buildStarRating((rating) {
              setState(() {
                _driverRating = rating;
              });
            }, _driverRating),
            const SizedBox(height: defaultPadding * 1.5),
            TextField(
              controller: _feedbackController,
              maxLines: 3,
              decoration: const InputDecoration(
                hintText: 'Share your feedback (optional)',
                fillColor: Color(0xFFE8F5E9), // Light green background from mockup
                filled: true,
                border: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.green), // Green border
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.green),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.green, width: 1.5),
                ),
              ),
            ),
            const SizedBox(height: defaultPadding * 2),
            const Divider(color: mediumGreyColor),
            const SizedBox(height: defaultPadding * 2),

            // Co-passenger Rating Section
            Text('Rate your co-passenger', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: defaultPadding),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                 const CircleAvatar(
                  radius: 20,
                  backgroundColor: mediumGreyColor,
                  child: Icon(Icons.person_outline, color: Colors.white, size: 24), // Placeholder Icon
                ),
                const SizedBox(width: defaultPadding),
                Text(coPassengerName, style: Theme.of(context).textTheme.titleMedium),
              ],
            ),
            const SizedBox(height: defaultPadding / 2),
            _buildStarRating((rating) {
              setState(() {
                _coPassengerRating = rating;
              });
            }, _coPassengerRating),
            const SizedBox(height: defaultPadding * 3),

            // Submit Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  // Handle submitting ratings - Placeholder
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Rating submitted! Driver: $_driverRating, Co-passenger: $_coPassengerRating')),
                  );
                  // Navigate back to HomeScreen after submitting rating
                  Navigator.of(context).popUntil((route) => route.isFirst);
                },
                child: const Text('Submit Rating'),
              ),
            ),
            const SizedBox(height: defaultPadding), // Bottom padding
          ],
        ),
      ),
    );
  }

  Widget _buildStarRating(ValueChanged<double> onRatingChanged, double currentRating) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(5, (index) {
        return IconButton(
          onPressed: () {
            onRatingChanged(index + 1.0);
          },
          icon: Icon(
            index < currentRating ? Icons.star : Icons.star_border,
            color: Colors.amber,
            size: 35,
          ),
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(),
        );
      }),
    );
  }
}

