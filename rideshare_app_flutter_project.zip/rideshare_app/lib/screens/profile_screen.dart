import 'package:flutter/material.dart';
import 'package:rideshare_app/utils/constants.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Dummy data based on mockup - replace with actual data later
    const String userName = 'Amit Sharma';
    const String userPhone = '+91 98765 43210';
    const double userRating = 4.3;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        // leading: IconButton( // Add back button if needed, depends on navigation flow
        //   icon: const Icon(Icons.arrow_back),
        //   onPressed: () => Navigator.of(context).pop(),
        // ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(defaultPadding),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: defaultPadding),
            const CircleAvatar(
              radius: 50,
              backgroundColor: mediumGreyColor,
              child: Icon(Icons.person, color: Colors.white, size: 60), // Placeholder Icon
            ),
            const SizedBox(height: defaultPadding),
            Text(userName, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: defaultPadding / 4),
            Text(userPhone, style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: textLightColor)),
            const SizedBox(height: defaultPadding / 2),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.star, color: Colors.amber, size: 20),
                const SizedBox(width: 4),
                Text(userRating.toString(), style: Theme.of(context).textTheme.titleMedium),
              ],
            ),
            const SizedBox(height: defaultPadding * 2),
            const Divider(color: mediumGreyColor),
            const SizedBox(height: defaultPadding),

            // Account Settings Section
            Align(
              alignment: Alignment.centerLeft,
              child: Text('Account Settings', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: defaultPadding / 2),
            _buildProfileOption(context, icon: Icons.edit_outlined, title: 'Edit Profile', onTap: () {}), // Placeholder onTap
            _buildProfileOption(context, icon: Icons.location_on_outlined, title: 'Saved Addresses', onTap: () {}),
            _buildProfileOption(context, icon: Icons.payment_outlined, title: 'Payment Methods', onTap: () {}),
            const SizedBox(height: defaultPadding * 1.5),

            // Activity Section
            Align(
              alignment: Alignment.centerLeft,
              child: Text('Activity', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: defaultPadding / 2),
            _buildProfileOption(context, icon: Icons.history_outlined, title: 'Ride History', onTap: () {}),
            _buildProfileOption(context, icon: Icons.receipt_long_outlined, title: 'Payment History', onTap: () {}),
            const SizedBox(height: defaultPadding * 2),

            // Logout Button (Optional - Not in mockup, but common)
            // OutlinedButton.icon(
            //   onPressed: () {},
            //   icon: const Icon(Icons.logout, color: Colors.red),
            //   label: const Text('Logout', style: TextStyle(color: Colors.red)),
            //   style: OutlinedButton.styleFrom(
            //     side: const BorderSide(color: Colors.red),
            //   ),
            // ),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileOption(BuildContext context, {required IconData icon, required String title, required VoidCallback onTap}) {
    return Card(
      elevation: 0,
      margin: const EdgeInsets.symmetric(vertical: defaultPadding / 4),
      color: lightGreyColor.withOpacity(0.5),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(defaultRadius)),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(defaultPadding / 2),
          decoration: BoxDecoration(
            color: primaryColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(defaultRadius / 2),
          ),
          child: Icon(icon, color: primaryColor, size: 20),
        ),
        title: Text(title, style: Theme.of(context).textTheme.bodyLarge),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: textLightColor),
        onTap: onTap,
      ),
    );
  }
}

